# Owner final checklist

Current decision: **CONDITIONAL GO — production push not approved by offline evidence.**

1. Review the final diff and [executive decision](00-FINAL-EXECUTIVE-DECISION.md); accept private-only release and [residual risks](05-RESIDUAL-RISKS-AND-DEFERRED-FEATURES.md). Sharing, scoped creators/reporting and CODEX 2/3 remain deferred.
2. Identify your intended Supabase project and synthetic staging environment. Separately approve/operator-run the bounded inspection and fixtures in [03](03-SUPABASE-OWNER-ACTION-SHEET.md)/[04](04-PUSH-AND-ROLLBACK-RUNBOOK.md). No permission to contact live services was used here.
3. Complete read-only schema/RLS/grants/count/Auth/private Storage checks. **No new Supabase schema/configuration changes required** if checked-in contracts are deployed. Stop and review drift instead of weakening permissions or applying all migrations.
4. Approve and complete exact-artifact production build in a controlled environment; retain output, Node/package versions and artifact ID. No offline build pass is claimed.
5. Pass bounded synthetic privacy, directory/contact, operational audit/export, save/reset/account-switch, resource signing and publish-recovery gate. Record actual counters and evidence. Any unauthorized payload or lost acknowledged value is NO-GO.
6. Explicitly accept remaining multi-step/cross-tab/device-draft limitations and documented feature/availability reductions, or defer push. Reload old generic/LMU forms after preserving drafts; LMU old clients receive 409 on save/reset.
7. Confirm branch `main` and `origin` match your intention and pushing it will not unexpectedly deploy. Selectively stage/review, commit and push only via [04](04-PUSH-AND-ROLLBACK-RUNBOOK.md) after all gates pass. Approve production release separately; this agent neither commits nor pushes.
8. Run bounded post-deployment synthetic smoke checks and monitor errors/audit/save receipts; stop on defined failures. Keep the reviewed privacy-preserving rollback artifact ready. No destructive data rollback.

Record sign-off: operator/date, project/deployment, build/commit ID, checks and request/byte/mutation counts, failures/resolution, explicit residual-risk acceptance and push authorization. Until recorded, this remains CONDITIONAL GO.

## Authorized release verification update

October 10, 2026. Owner authorized read-only Supabase compatibility checks, a production build, automated tests and Git preparation. No push/deployment, migrations, Supabase mutations, private participant reads or synthetic production writes were performed.

**Verified project:** local `.env.local` hostname and `supabase/.temp/project-ref` both match `xxjiiqrhnniccnxujmnv`; connected project metadata identifies `wayfinders-os`, ACTIVE_HEALTHY, us-east-1, Postgres 17.6. No credentials were displayed.

**Supabase metadata passed:** 20/20 required tables exist with RLS enabled; anon/authenticated have no SELECT or INSERT/UPDATE/DELETE privileges; service role SELECT exists. Protected-policy subset and all Storage object policies are empty, consistent with server-mediated access. Fifteen checked unique/check constraints and 29 indexes include generic enrollment/definition uniqueness, canonical participant/course uniqueness, LMU assessment/section uniqueness and permission/role scope/effect/status contracts. All 25 targeted columns match required types. Four required RPCs match signatures, deny anon/authenticated EXECUTE and allow service role. `purposeos-assets` is private, 26,214,400-byte limit, expected 14 MIME types. These were four bounded SQL metadata queries in `BEGIN TRANSACTION READ ONLY ... ROLLBACK`; no function was invoked. No result hit its 50-row cap.

**Data API exact counts passed:** two service-role HEAD-only requests to nonsensitive role/permission catalogs returned HTTP 200 and numeric exact counts (41 role-permission mappings; 31 role-entitlement mappings); zero response bodies. No participant/override rows were accessed. The authenticator-role catalog exposed no explicit row-limit setting; configured Data API maximum remains unverified. Real scoped directory/contact/override behavior, Auth URL/session configuration, browser payloads and withdrawal signing remain unverified.

**Production build passed with a temporary network guard:** `NEXT_TELEMETRY_DISABLED=1 NODE_OPTIONS='--require=/private/tmp/codex1-build-network-guard.cjs' npm run build`, exit 0. Installed Node v26.0.0/Next 16.3.6; compilation, Next TypeScript and 95/95 page-generation tasks completed; build ID `UL-N9OHvDw9Zm5DIp6I47`. Guard permitted Google font hosts and loopback only, blocked six requests to the identified Supabase host; no participant data was fetched. Guard is outside repository, not a committed config change. This proves guarded build compilation/generation, not deployed runtime/Supabase integration. Use a fresh approved release build after final gates; do not deploy this artifact as certified production-runtime evidence.

**Automated verification passed:** 264/264 combined checks, zero failed/skipped/cancelled; standalone TypeScript exit 0; ESLint exit 0 across 37 allowlisted application files, zero errors/one existing unused `userEmail` warning; `git diff --check` passed. The combined test command is the report 02 core command plus the LMU suite and six broader suites in one `node --test` invocation. Tests are static/unit/mock, not live writes.

**Git:** branch `main`, `origin` = `https://github.com/GilesEmery/wayfinders-os.git`; exact 72-path allowlist verified, all 35 modified tracked paths covered, excluded original audit reports/ZIP/secrets/migrations/build output. New code/tests are included; staged index remains empty. No fetch, staging, commit, push or deployment performed; remote divergence/automatic deployment hook remain unverified.

**Remaining gate / stop for owner decision:** the identified Supabase project has no development branches. Connected project discovery identified no PurposeOS staging project; the separately listed `peaceworks-portal` is unrelated and was not queried. No safe staging target/operator/prepared fixture identities were supplied. Current authorization permits read-only Supabase activity and prohibits creating/modifying users, grants or objects, so required save/reset/publication/signing/revocation integration tests cannot be safely completed here. Recommendation remains **CONDITIONAL GO, not production approved**. Do not create the Git commit under the current “after all required checks pass” condition.

**Exact next owner action:** identify an existing isolated PurposeOS staging project/deployment and explicitly authorize a bounded validation plan with prepared synthetic identities and the precise permitted fixture writes; otherwise explicitly decide to defer release or request a separately documented residual-risk exception. No production write testing or blanket grant change is proposed. Final production push still requires your separate approval after the resulting gates pass. CODEX 2/3 were not begun.

## October 12 completion execution and owner staging decision

The owner explicitly chose to skip staging setup on October 12 and continue release preparation. This is acceptance of the disclosed untested integration risks, not evidence that staging passed. No staging resources, costs, migrations, fixture writes, credentials changes, production data reads or writes were performed. Production push/deployment still requires separate final approval.

- CODEX 1 code/test files are unchanged since the 264-check passing run; the 72-path selective list covers all pending tracked release edits. Prior suites were not unnecessarily repeated. Read-only production Supabase contract evidence from October 10 is retained; no evidence of a contract change prompted repetition.
- Local and remote `main` match `363a542c0df69f64f98c15286112cbe82b877387`. Vercel's latest READY production deployment is `dpl_Ds3DAazwS1PEXMDnemMcbhJAHixe`, built from that same `main` SHA. GitHub integration links `GilesEmery/wayfinders-os`.
- Production target: Vercel project `wayfinders-os` / `prj_569lm7OPIHhr7pAoMmxEWb2xDrcp`, team `gilesemerys-projects` / `team_cgPcgpCMTyiMoDSjgSjNxipT`; public alias `https://wayfinders-os.vercel.app`. Treat a `main` push as a production deployment. Both existing Preview and Production Supabase URL settings point to `xxjiiqrhnniccnxujmnv.supabase.co`; Preview is not an isolated test database. No environment setting was changed.
- Vercel runtime is Node `24.x`. A checksum-verified official Node `v24.21.0` was downloaded into temporary storage, without modifying dependencies or system runtime. A new guarded Next production build on that runtime passed, exit 0: compilation, Next TypeScript, 95/95 page generation. Build ID `zIOrb9D12yZOMHDhwmBHA`. The temporary guard blocked 8 Supabase requests and allowed only font hosts/loopback. This verifies build compatibility, not production data/runtime integration. Deployment must build the reviewed source through Vercel; do not upload this guarded local build as a certified live artifact.
- Still NOT TESTED: live authenticated owner/nonowner payloads, real save/reload/CAS/reset/cross-tab behavior, permission revocation, resource signing, and synthetic publish/reorder recovery. Auth URL/session settings and configured Data API maximum remain unverified. No code/grant workaround is introduced to claim a pass. Sharing, scoped creator/reporting, privileged private exceptions, schema changes, CODEX 2/3 stay deferred.

Recommendation: **CONDITIONAL GO with owner-accepted staging waiver**. No known reproducible critical leak remains in the reviewed local patch, but unperformed integration checks cannot be certified. Before commit/push, show the release gate table and exact file list, obtain explicit final approval, and verify that the approved file contents and remote HEAD are unchanged. Commit title: `Complete CODEX 1 security and data integrity safeguards`. Scope: the runbook's 72 paths only; exclude original audits, ZIPs, secrets, migrations and build artifacts.

After separately approved push, monitor the matching Vercel deployment for READY and inspect sanitized build failure evidence if needed. Proposed production smoke scope: at most 10 anonymous read-only HTTP requests to public landing/admin-login/anonymous-denied API surfaces, at most 2 MiB transfer and five minutes; no accounts, answers, synthetic records, uploads or writes. Authenticated save/owner/Storage smoke remains NOT TESTED under the staging waiver. Ask separately before any broader test.

Recovery preserves privacy: do not automatically roll back to the pre-CODEX deployment, which restores audited weaknesses. On a new privacy/identity failure, stop testing; request incident approval to pause production access, then prepare a focused forward correction retaining owner-only gates. On build failure before promotion, leave the existing live deployment untouched and ask before correction/redeployment. No SQL rollback/delete/pointer reset is authorized.

### External Actions Required

**None before final approval:** Codex can perform the selective commit, push and deployment monitoring with existing connections. The required involvement now is your explicit commit/production-push approval in this conversation; do not paste credentials.

**Emergency fallback only if Codex's Vercel connection becomes unavailable:** after explicit incident approval, an authenticated operator or ChatGPT HAL can pause the production project. In a terminal with the Vercel CLI already installed and logged into the correct team, first confirm the command with `vercel project pause --help`, then execute:

```sh
vercel --scope gilesemerys-projects project pause wayfinders-os
```

This blocks the active production deployment and disables automatic production-domain assignment; it does not alter Supabase data or restore older vulnerable code. Verify `https://wayfinders-os.vercel.app` no longer serves the application, with one anonymous request. Do not execute this as part of normal release preparation. Resuming/promoting requires a reviewed safe artifact and separate approval. If login is required, use the provider's browser login flow; never share a token in chat.

## Approved release attempt — October 12

Final owner approval was received in Codex (first approval option). Exactly 72 approved files were staged, byte-checked against the approval manifest, committed as `b0b34e94bea07b1524cff24344389f496fa29221`, and pushed without force to `origin/main`. Unrelated original audits and ZIP remained excluded. GitHub confirms author login `GilesEmery`; author email matches the prior successful commit. No code correction, schema change or participant write occurred.

Vercel production deployment `dpl_An4tMhwwzhd6XtSWW2N7JAeB5uHH` failed with `git_info_fail` before build logs were produced; GitHub Vercel status is failure. No diagnosis beyond Git metadata/integration failure is proven. Prior READY deployment `dpl_Ds3DAazwS1PEXMDnemMcbhJAHixe` still owns production aliases. One approved anonymous HEAD request to `https://wayfinders-os.vercel.app` returned 200; zero body bytes were read. This does not validate the new release. CODEX 1 is not deployed/closed yet.

### External Actions Required if the Git connection needs owner attention

1. Open `https://vercel.com/gilesemerys-projects/wayfinders-os/An4tMhwwzhd6XtSWW2N7JAeB5uHH` in your signed-in browser. Review the error details for `git_info_fail`; do not redeploy automatically or change settings yet.
2. In Vercel → `wayfinders-os` → Settings → Git, confirm the connected repository is `GilesEmery/wayfinders-os`. In `https://vercel.com/account/settings/authentication`, confirm the owner account's GitHub login connection is `GilesEmery`. These are inspections, not instructions to disconnect/reconnect or upgrade plans. Report only the error text/connection status to Codex or ChatGPT HAL; never send tokens.
3. Recommended first correction for approval: one server-side Vercel redeployment of failed deployment ID `dpl_An4tMhwwzhd6XtSWW2N7JAeB5uHH`, preserving source commit `b0b34e94bea07b1524cff24344389f496fa29221` and existing production settings. Codex can execute this with the connected Vercel API after approval. No force push, code change, paid upgrade, environment change or Supabase mutation is required. If it fails again, stop and obtain the specific provider connection/login remedy rather than loop.
4. Verify success only when Vercel reports READY for the exact release SHA and assigns the production alias; then complete the remaining approved anonymous read-only smoke requests. Any wider authenticated/write smoke needs separate approval.

## Deployment retry and anonymous-login correction

The owner approved one Vercel retry. Deployment `dpl_GXL56qNb5oGinvU7SQ6jH2oeBFs2` reached READY for `b0b34e94bea07b1524cff24344389f496fa29221` and received the production aliases. No setting or Git identity change was needed. Approved anonymous smoke then found public landing 200 and `/admin/login` 500; testing stopped. The earlier Git integration failure is resolved, but CODEX 1 cannot close with a broken anonymous login.

Local root-cause verification using the installed Supabase SDK confirms `getUser()` with no session returns `AuthSessionMissingError`. The strict new admin guard treated this ordinary signed-out result as an exceptional identity outage. A two-line correction in `lib/admin/auth.ts` returns null only for that named missing-session state, before any privileged lookup. All other identity errors remain unavailable/denied; contradictory partial identity data cannot grant access. No permission, schema or participant-data change.

Four focused regressions were added in `scripts/security/codex1-final.test.mjs`. `node --test --test-name-pattern='admin' scripts/security/codex1-final.test.mjs scripts/security/codex1-1.test.mjs` passed 10/10 checks (four new plus six relevant retained cases). Auth-file ESLint and diff checks passed. Corrected Node 24 guarded production build passed. Original 264-check evidence is retained, not claimed as a new full run after this two-line change.

Actual loopback-only production HTTP checks with the database guard retained: login HEAD 200; admin HEAD 307 to `/admin/login`; anonymous private export, operational export and Journey HEAD each 403, with no-store. Five passes, zero body bytes read. Additional LMU HEAD returned 503 from the database-backed password proxy when its configuration lookup was blocked by the guard; that integration check is NOT TESTED, not evidence of an LMU defect or pass. The guard remains intact.

Approval requested: commit/push only `lib/admin/auth.ts`, `scripts/security/codex1-final.test.mjs`, and this release checklist, with title `Handle signed-out admin sessions without login errors`. This includes the live deployment/failure record and the focused fix. No rollback to old privacy behavior, Supabase write or new cloud resource is proposed. Remaining approved anonymous production smoke budget: seven requests (three already used, including the prior-deployment health HEAD). Wider authenticated/write smoke still requires separate authorization.


---

# CODEX 1 release closeout — October 12, 2026

**Completed for the owner-approved release scope.** The security improvements and anonymous-admin-login correction are deployed successfully. Staging and broader authenticated integration testing were explicitly waived by the owner; those checks remain NOT TESTED, not certified passes.

- Production: https://wayfinders-os.vercel.app
- Final source commit: `e48acace6954a6a10772acfbb34cc013f192f284` (login correction), following security commit `b0b34e94bea07b1524cff24344389f496fa29221`.
- Vercel: `wayfinders-os`, project `prj_569lm7OPIHhr7pAoMmxEWb2xDrcp`, team `gilesemerys-projects`.
- Final deployment: `dpl_Hjz8RMxiHSufD8gNjE9WSS4uUQAi`, production, **READY**, exact final source SHA verified; production aliases assigned.
- Deployment URL: https://wayfinders-m648o9d8u-gilesemerys-projects.vercel.app

## Completed verification

Prior read-only Supabase checks passed for protected RLS/grants, required database contracts, server-only RPCs, private Storage configuration and catalog exact counts. No production participant records were read or mutated; no migrations, schema, permission, account or Supabase Storage changes were made.

The original 264 isolated checks were retained without unnecessary repetition. The small login correction passed 10 focused admin checks, including four new missing-session/identity-failure cases, and a guarded production build on Node 24. Five local HTTP checks passed; local LMU middleware could not be tested while its database lookup was blocked. Full authenticated end-to-end behavior remains outside the accepted validation scope.

Final production smoke: seven anonymous HEAD requests, zero body bytes read, no accounts or writes. Together with three earlier approved health/failure requests, the ten-request production smoke cap was respected.

| Check | Result |
| --- | --- |
| Public landing | 200 PASS |
| Admin login | 200 PASS |
| Admin entry | 307 to login PASS |
| Private CSV export, sentinel ID | 403 + no-store PASS |
| Operational CSV export, sentinel ID | 403 + no-store PASS |
| Journey API, sentinel ID | 403 + no-store PASS |
| LMU anonymous access | 401 PASS |

## Deployment issue resolved

The dashboard revealed the cause of `git_info_fail`: GitHub HTTP 403 secondary rate limiting. After a cooldown, the same repository displayed Connected and a normal Git-based deployment succeeded. No credential rotation, repository disconnection/reconnection, permission expansion, billing upgrade or setting change was needed.

The alternate source-upload workaround was stopped. It confirmed 100 source-file uploads before termination, but created no deployment through that route. No staging fixtures/resources were created, and no staging cleanup is required. Temporary local tooling and the source upload cache were not included in Git or the ZIP.

## Remaining accepted limitations and deferred work

Authenticated owner/nonowner payloads, actual save/reload/CAS/reset/cross-tab races, resource signing/revocation and publish/reorder recovery were not live-tested. Multi-step writes remain a documented risk. Auth URL/session settings and the configured Data API maximum were not independently verified. These limitations were disclosed before the owner approved release without staging.

Facilitator/group sharing, broad private-content exceptions, scoped creator/reporting expansion, result/free-text analytics, CODEX 2 and CODEX 3 remain deferred. No newly discovered blocker remains for this approved release scope. No claim of an incident investigation or absence of every vulnerability is made.

## External Actions Required

**NONE to complete this release.** Codex committed, pushed, deployed, and completed the approved smoke checks. This closeout and the refreshed seven-document ZIP are local reporting artifacts, deliberately not pushed as another deployment-triggering documentation commit. Existing unrelated original audits remain preserved.

If GitHub secondary-rate errors recur on a future release: stop Git/API retries; follow any Retry-After instruction, otherwise wait at least one minute; inspect Vercel project Settings → Git once. Repeated failures require increasing backoff and provider investigation, not blind reconnects or permission changes. A future production retry still needs the appropriate owner authorization. Never roll back to older code that restores known privacy weaknesses merely to resolve a hosting integration error.
